return {
	{
		coords = vec3(-305.683, -1065.032, 28.33),
		target = { -- qtarget support
			name = 'mrpd_evidence', -- name of zone must be uniuqe
			loc = vec3(-305.683, -1065.032, 28.33),
			length = 1.4,
			width = 3.2,
			heading = 0,
			minZ = 29.09,
			maxZ = 31.89
		}
	}
}